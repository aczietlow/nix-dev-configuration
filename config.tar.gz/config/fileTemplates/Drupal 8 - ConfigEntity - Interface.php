<?php

namespace Drupal\$module\ConfigEntity;

use \Drupal\Core\Config\Entity\ConfigEntityInterface;

/**
 * Interface ${NAME}.
 */
interface ${NAME} extends ConfigEntityInterface {}
