<?php
/**
 * @file
 * Drush runtime configuration.
 * 
 * @see http://drush.ws/examples/example.drushrc.php
 */

//drushrc_command_specific_