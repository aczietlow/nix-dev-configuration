/**
 * @file
 * Documentation missing.
 */

(function ($) {
  'use strict';
  Drupal.behaviors.${FILE_NAME} = {
    attach: function (context, settings) {
      // Do something.
    }
  };
}(jQuery));
