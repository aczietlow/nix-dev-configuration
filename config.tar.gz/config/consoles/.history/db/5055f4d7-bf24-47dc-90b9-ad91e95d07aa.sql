SELECT node_og_membership_1.nid AS node_og_membership_1_nid, node_og_membership_1.title AS node_og_membership_1_title, node_og_membership_1.type AS node_og_membership_1_type, users_node_revision.name AS users_node_revision_name, users_node_revision.uid AS users_node_revision_uid, node_og_membership_1__workbench_moderation_node_history.state AS node_og_membership_1__workbench_moderation_node_history_stat
FROM
og_membership og_membership
LEFT JOIN node node_og_membership ON og_membership.gid = node_og_membership.nid AND og_membership.group_type = 'node'
LEFT JOIN og_membership og_membership_node ON node_og_membership.nid = og_membership_node.gid AND og_membership_node.group_type = 'node'
LEFT JOIN node node_og_membership_1 ON og_membership_node.etid = node_og_membership_1.nid AND og_membership_node.entity_type = 'node'
LEFT JOIN node_revision node_og_membership_1__node_revision ON node_og_membership_1.vid = node_og_membership_1__node_revision.vid
LEFT JOIN users users_node_revision ON node_og_membership_1__node_revision.uid = users_node_revision.uid
INNER JOIN workbench_moderation_node_history node_og_membership_1__workbench_moderation_node_history ON node_og_membership_1.nid = node_og_membership_1__workbench_moderation_node_history.nid
WHERE (( (og_membership.etid = '1' ) )AND(( (node_og_membership_1__workbench_moderation_node_history.is_current <> '0') AND (og_membership.entity_type LIKE 'user' ESCAPE '\\') AND (og_membership.state IN  ('1')) AND (node_og_membership.type IN  ('content_group')) )))
ORDER BY node_og_membership_1_title ASC
LIMIT 25 OFFSET 0
;-- -. . -..- - / . -. - .-. -.--
SELECT node_og_membership_1.nid AS node_og_membership_1_nid, node_og_membership_1.title AS node_og_membership_1_title, node_og_membership_1.type AS node_og_membership_1_type, users_node_revision.name AS users_node_revision_name, users_node_revision.uid AS users_node_revision_uid, node_og_membership_1__workbench_moderation_node_history.state AS node_og_membership_1__workbench_moderation_node_history_stat
FROM
og_membership og_membership
LEFT JOIN node node_og_membership ON og_membership.gid = node_og_membership.nid AND og_membership.group_type = 'node'
LEFT JOIN og_membership og_membership_node ON node_og_membership.nid = og_membership_node.gid AND og_membership_node.group_type = 'node'
LEFT JOIN node node_og_membership_1 ON og_membership_node.etid = node_og_membership_1.nid AND og_membership_node.entity_type = 'node'
LEFT JOIN node_revision node_og_membership_1__node_revision ON node_og_membership_1.vid = node_og_membership_1__node_revision.vid
LEFT JOIN users users_node_revision ON node_og_membership_1__node_revision.uid = users_node_revision.uid
INNER JOIN workbench_moderation_node_history node_og_membership_1__workbench_moderation_node_history ON node_og_membership_1.nid = node_og_membership_1__workbench_moderation_node_history.nid
WHERE (( (og_membership.etid = '1' ) )AND(( (node_og_membership_1__workbench_moderation_node_history.is_current <> '0') AND (og_membership.entity_type LIKE 'user' ESCAPE '\\') AND (og_membership.state IN  ('1')) AND (node_og_membership.type IN  ('content_group')) )))
GROUP BY node_og_membership_1_nid, node_og_membership_1_title, node_og_membership_1_type, users_node_revision_name, users_node_revision_uid, node_og_membership_1__workbench_moderation_node_history_stat
ORDER BY node_og_membership_1_title ASC
LIMIT 25 OFFSET 0
;-- -. . -..- - / . -. - .-. -.--
SELECT node_og_membership_1.nid AS node_og_membership_1_nid, node_og_membership_1.title AS node_og_membership_1_title, node_og_membership_1.type AS node_og_membership_1_type, users_node_revision.name AS users_node_revision_name, users_node_revision.uid AS users_node_revision_uid, node_og_membership_1__workbench_moderation_node_history.state AS node_og_membership_1__workbench_moderation_node_history_stat
FROM
og_membership og_membership
LEFT JOIN node node_og_membership ON og_membership.gid = node_og_membership.nid AND og_membership.group_type = 'node'
LEFT JOIN og_membership og_membership_node ON node_og_membership.nid = og_membership_node.gid AND og_membership_node.group_type = 'node'
LEFT JOIN node node_og_membership_1 ON og_membership_node.etid = node_og_membership_1.nid AND og_membership_node.entity_type = 'node'
LEFT JOIN node_revision node_og_membership_1__node_revision ON node_og_membership_1.vid = node_og_membership_1__node_revision.vid
LEFT JOIN users users_node_revision ON node_og_membership_1__node_revision.uid = users_node_revision.uid
INNER JOIN workbench_moderation_node_history node_og_membership_1__workbench_moderation_node_history ON node_og_membership_1.nid = node_og_membership_1__workbench_moderation_node_history.nid
WHERE (( (og_membership.etid = '1' ) )AND(( (node_og_membership_1__workbench_moderation_node_history.is_current <> '0') AND (og_membership.entity_type LIKE 'user' ESCAPE '\\') AND (og_membership.state IN  ('1')) AND (node_og_membership.type IN  ('content_group')) )))
GROUP BY node_og_membership_1_nid, node_og_membership_1_title, node_og_membership_1_type, users_node_revision_name, users_node_revision_uid, node_og_membership_1__workbench_moderation_node_history_stat
ORDER BY node_og_membership_1_title ASC
;-- -. . -..- - / . -. - .-. -.--
SELECT node_og_membership_1.nid AS node_og_membership_1_nid, node_og_membership_1.title AS node_og_membership_1_title, node_og_membership_1.type AS node_og_membership_1_type, users_node_revision.name AS users_node_revision_name, users_node_revision.uid AS users_node_revision_uid, node_og_membership_1__workbench_moderation_node_history.state AS node_og_membership_1__workbench_moderation_node_history_stat
FROM
og_membership og_membership
LEFT JOIN node node_og_membership ON og_membership.gid = node_og_membership.nid AND og_membership.group_type = 'node'
LEFT JOIN og_membership og_membership_node ON node_og_membership.nid = og_membership_node.gid AND og_membership_node.group_type = 'node'
LEFT JOIN node node_og_membership_1 ON og_membership_node.etid = node_og_membership_1.nid AND og_membership_node.entity_type = 'node'
LEFT JOIN node_revision node_og_membership_1__node_revision ON node_og_membership_1.vid = node_og_membership_1__node_revision.vid
LEFT JOIN users users_node_revision ON node_og_membership_1__node_revision.uid = users_node_revision.uid
INNER JOIN workbench_moderation_node_history node_og_membership_1__workbench_moderation_node_history ON node_og_membership_1.nid = node_og_membership_1__workbench_moderation_node_history.nid
WHERE (( (og_membership.etid = '1' ) )AND(( (node_og_membership_1__workbench_moderation_node_history.is_current <> '0') AND (og_membership.entity_type LIKE 'user' ESCAPE '\\') AND (og_membership.state IN  ('1')) AND (node_og_membership.type IN  ('content_group')) )))
ORDER BY node_og_membership_1_title ASC
OFFSET 0
;-- -. . -..- - / . -. - .-. -.--
SELECT count(node_og_membership_1.nid) AS node_og_membership_1_nid, node_og_membership_1.title AS node_og_membership_1_title, node_og_membership_1.type AS node_og_membership_1_type, users_node_revision.name AS users_node_revision_name, users_node_revision.uid AS users_node_revision_uid, node_og_membership_1__workbench_moderation_node_history.state AS node_og_membership_1__workbench_moderation_node_history_stat
FROM
og_membership og_membership
LEFT JOIN node node_og_membership ON og_membership.gid = node_og_membership.nid AND og_membership.group_type = 'node'
LEFT JOIN og_membership og_membership_node ON node_og_membership.nid = og_membership_node.gid AND og_membership_node.group_type = 'node'
LEFT JOIN node node_og_membership_1 ON og_membership_node.etid = node_og_membership_1.nid AND og_membership_node.entity_type = 'node'
LEFT JOIN node_revision node_og_membership_1__node_revision ON node_og_membership_1.vid = node_og_membership_1__node_revision.vid
LEFT JOIN users users_node_revision ON node_og_membership_1__node_revision.uid = users_node_revision.uid
INNER JOIN workbench_moderation_node_history node_og_membership_1__workbench_moderation_node_history ON node_og_membership_1.nid = node_og_membership_1__workbench_moderation_node_history.nid
WHERE (( (og_membership.etid = '1' ) )AND(( (node_og_membership_1__workbench_moderation_node_history.is_current <> '0') AND (og_membership.entity_type LIKE 'user' ESCAPE '\\') AND (og_membership.state IN  ('1')) AND (node_og_membership.type IN  ('content_group')) )))
GROUP BY node_og_membership_1_nid, node_og_membership_1_title, node_og_membership_1_type, users_node_revision_name, users_node_revision_uid, node_og_membership_1__workbench_moderation_node_history_stat
ORDER BY node_og_membership_1_title ASC
;-- -. . -..- - / . -. - .-. -.--
SELECT count(node_og_membership.title) as test_title,node_og_membership_1.nid AS node_og_membership_1_nid, node_og_membership_1.title AS node_og_membership_1_title, node_og_membership_1.type AS node_og_membership_1_type, users_node_revision.name AS users_node_revision_name, users_node_revision.uid AS users_node_revision_uid, node_og_membership_1__workbench_moderation_node_history.state AS node_og_membership_1__workbench_moderation_node_history_stat
FROM
og_membership og_membership
LEFT JOIN node node_og_membership ON og_membership.gid = node_og_membership.nid AND og_membership.group_type = 'node'
LEFT JOIN og_membership og_membership_node ON node_og_membership.nid = og_membership_node.gid AND og_membership_node.group_type = 'node'
LEFT JOIN node node_og_membership_1 ON og_membership_node.etid = node_og_membership_1.nid AND og_membership_node.entity_type = 'node'
LEFT JOIN node_revision node_og_membership_1__node_revision ON node_og_membership_1.vid = node_og_membership_1__node_revision.vid
LEFT JOIN users users_node_revision ON node_og_membership_1__node_revision.uid = users_node_revision.uid
INNER JOIN workbench_moderation_node_history node_og_membership_1__workbench_moderation_node_history ON node_og_membership_1.nid = node_og_membership_1__workbench_moderation_node_history.nid
WHERE (( (og_membership.etid = '1' ) )AND(( (node_og_membership_1__workbench_moderation_node_history.is_current <> '0') AND (og_membership.entity_type LIKE 'user' ESCAPE '\\') AND (og_membership.state IN  ('1')) AND (node_og_membership.type IN  ('content_group')) )))
GROUP BY node_og_membership_1_nid, node_og_membership_1_title, node_og_membership_1_type, users_node_revision_name, users_node_revision_uid, node_og_membership_1__workbench_moderation_node_history_stat
ORDER BY node_og_membership_1_title ASC
;-- -. . -..- - / . -. - .-. -.--
SELECT node_og_membership.title as test_title,node_og_membership_1.nid AS node_og_membership_1_nid, node_og_membership_1.title AS node_og_membership_1_title, node_og_membership_1.type AS node_og_membership_1_type, users_node_revision.name AS users_node_revision_name, users_node_revision.uid AS users_node_revision_uid, node_og_membership_1__workbench_moderation_node_history.state AS node_og_membership_1__workbench_moderation_node_history_stat
FROM
og_membership og_membership
LEFT JOIN node node_og_membership ON og_membership.gid = node_og_membership.nid AND og_membership.group_type = 'node'
LEFT JOIN og_membership og_membership_node ON node_og_membership.nid = og_membership_node.gid AND og_membership_node.group_type = 'node'
LEFT JOIN node node_og_membership_1 ON og_membership_node.etid = node_og_membership_1.nid AND og_membership_node.entity_type = 'node'
LEFT JOIN node_revision node_og_membership_1__node_revision ON node_og_membership_1.vid = node_og_membership_1__node_revision.vid
LEFT JOIN users users_node_revision ON node_og_membership_1__node_revision.uid = users_node_revision.uid
INNER JOIN workbench_moderation_node_history node_og_membership_1__workbench_moderation_node_history ON node_og_membership_1.nid = node_og_membership_1__workbench_moderation_node_history.nid
WHERE (( (og_membership.etid = '1' ) )AND(( (node_og_membership_1__workbench_moderation_node_history.is_current <> '0') AND (og_membership.entity_type LIKE 'user' ESCAPE '\\') AND (og_membership.state IN  ('1')) AND (node_og_membership.type IN  ('content_group')) )))
GROUP BY node_og_membership_1_nid, node_og_membership_1_title, node_og_membership_1_type, users_node_revision_name, users_node_revision_uid, node_og_membership_1__workbench_moderation_node_history_stat
ORDER BY node_og_membership_1_title ASC
;-- -. . -..- - / . -. - .-. -.--
SELECT count(node_og_membership_1.nid) AS node_og_membership_1_nid, node_og_membership_1.title AS node_og_membership_1_title, node_og_membership_1.type AS node_og_membership_1_type, users_node_revision.name AS users_node_revision_name, users_node_revision.uid AS users_node_revision_uid, node_og_membership_1__workbench_moderation_node_history.state AS node_og_membership_1__workbench_moderation_node_history_stat
FROM
og_membership og_membership
LEFT JOIN node node_og_membership ON og_membership.gid = node_og_membership.nid AND og_membership.group_type = 'node'
LEFT JOIN og_membership og_membership_node ON node_og_membership.nid = og_membership_node.gid AND og_membership_node.group_type = 'node'
LEFT JOIN node node_og_membership_1 ON og_membership_node.etid = node_og_membership_1.nid AND og_membership_node.entity_type = 'node'
LEFT JOIN node_revision node_og_membership_1__node_revision ON node_og_membership_1.vid = node_og_membership_1__node_revision.vid
LEFT JOIN users users_node_revision ON node_og_membership_1__node_revision.uid = users_node_revision.uid
INNER JOIN workbench_moderation_node_history node_og_membership_1__workbench_moderation_node_history ON node_og_membership_1.nid = node_og_membership_1__workbench_moderation_node_history.nid
WHERE (( (og_membership.etid = '1' ) )AND(( (node_og_membership_1__workbench_moderation_node_history.is_current <> '0') AND (og_membership.entity_type LIKE 'user' ESCAPE '\\') AND (og_membership.state IN  ('1')) AND (node_og_membership.type IN  ('content_group')) )))
ORDER BY node_og_membership_1_title ASC
;-- -. . -..- - / . -. - .-. -.--
SELECT node_og_membership_1.nid AS node_og_membership_1_nid, node_og_membership_1.title AS node_og_membership_1_title, node_og_membership_1.type AS node_og_membership_1_type, users_node_revision.name AS users_node_revision_name, users_node_revision.uid AS users_node_revision_uid, node_og_membership_1__workbench_moderation_node_history.state AS node_og_membership_1__workbench_moderation_node_history_stat
FROM
og_membership og_membership
LEFT JOIN node node_og_membership ON og_membership.gid = node_og_membership.nid AND og_membership.group_type = 'node'
LEFT JOIN og_membership og_membership_node ON node_og_membership.nid = og_membership_node.gid AND og_membership_node.group_type = 'node'
LEFT JOIN node node_og_membership_1 ON og_membership_node.etid = node_og_membership_1.nid AND og_membership_node.entity_type = 'node'
LEFT JOIN node_revision node_og_membership_1__node_revision ON node_og_membership_1.vid = node_og_membership_1__node_revision.vid
LEFT JOIN users users_node_revision ON node_og_membership_1__node_revision.uid = users_node_revision.uid
INNER JOIN workbench_moderation_node_history node_og_membership_1__workbench_moderation_node_history ON node_og_membership_1.nid = node_og_membership_1__workbench_moderation_node_history.nid
WHERE (( (og_membership.etid = '1' ) )AND(( (node_og_membership_1__workbench_moderation_node_history.is_current <> '0') AND (og_membership.entity_type LIKE 'user' ESCAPE '\\') AND (og_membership.state IN  ('1')) AND (node_og_membership.type IN  ('content_group')) )))
ORDER BY node_og_membership_1_title ASC
;-- -. . -..- - / . -. - .-. -.--
SELECT * from file_managed
WHERE uid > 1
;-- -. . -..- - / . -. - .-. -.--
SELECT * from file_managed
WHERE uid > 1
AND status = 1
;-- -. . -..- - / . -. - .-. -.--
SELECT * from file_managed
WHERE uid > 1
AND status = 1
AND type = 'image'
AND uri NOT LIKE 'public://u', 'NOT LIKE'
;-- -. . -..- - / . -. - .-. -.--
SELECT * from file_managed
WHERE uid > 1
AND status = 1
AND type = 'image'
AND uri NOT LIKE 'public://u'
;-- -. . -..- - / . -. - .-. -.--
SELECT * from file_managed
WHERE uid > 1
      AND status = 1
      AND type = 'image'
      AND uri NOT LIKE 'public://u'
;-- -. . -..- - / . -. - .-. -.--
SELECT count(*) from file_managed
WHERE uid > 1
AND status = 1
AND type = 'image'
AND uri NOT LIKE 'public://u'
;-- -. . -..- - / . -. - .-. -.--
SELECT * from file_managed
WHERE uid > 1
      AND status = 1
      AND type = 'image'
      AND uri NOT LIKE 'public://u%'
;-- -. . -..- - / . -. - .-. -.--
SELECT count(*) from file_managed
WHERE uid > 1
AND status = 1
AND type = 'image'
AND uri NOT LIKE 'public://u%'