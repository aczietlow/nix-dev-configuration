SELECT count(*) from file_managed
WHERE uid > 1
AND status = 1
AND type = 'image'
AND uri NOT LIKE 'public://u%';

SELECT * from file_managed
WHERE uid > 1
      AND status = 1
      AND type = 'image'
      AND uri NOT LIKE 'public://u%';
