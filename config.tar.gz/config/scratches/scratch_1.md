# Trellon Admin Meeting

2017-01-03

* Alex
* Joe
* Mike
* Morbus
* Trevor
* Chris Z

## Agenda

### Projects

* CLPHA
  * Need to look at and review the deployment plan
  * There's an email discussing this
  * Trevor, Mike, and Alex are going to work on cleaning up the backlog
* Wiley
  * Tealium
* GFDRR updates
* GFDRR securiyy upgrades
* IAS USA
  * 9am tomorrow for a civiCRM walk through with Mike
* CPHLR
* Potpurri projects
* CDE
  * Mike #nailedIt
* PAUSD
* TAF
* Adapity
* Leaping Bunny

### New Hires



### Trellon.com


