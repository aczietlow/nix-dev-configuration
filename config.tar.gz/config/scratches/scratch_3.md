# Mindgrub

## Agile

* It's a new(ish) move within the company
* 2 week sprints
* Information radiators - monitors in the pods that display useful information
* Managed services isn't agile (support?)
  *  yet
* Use planning poker

## Git

* migrating to gitlab
* There's git guide for standards for web in confluence
* gitlab
  * continuous integration
  * git.mindgrub.com
  * has test runners
    * similar to circleci
  * gitlabci.yml
  * set up pipelines, environments, build artifacts
