pros:
 * like that it's responsive
 * These seems like a good visual representation of their data