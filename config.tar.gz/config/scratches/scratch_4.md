# My questions

* Do I need the training?

